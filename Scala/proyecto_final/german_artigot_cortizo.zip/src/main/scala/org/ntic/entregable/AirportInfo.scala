package org.ntic.entregable

case class AirportInfo(
                        airportId: Long,
                        code: String,
                        cityName: String,
                        stateAbr: String,
                      )